package web_service.webService;

import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;

public class main {

	public static void main(String[] args) {
		
		GeoIPService geoIpService = new GeoIPService();

		GeoIPServiceSoap  soap = geoIpService.getGeoIPServiceSoap();
		
		System.out.println(soap.getGeoIP("161.3.185.151").getCountryName());
		
	}

}
