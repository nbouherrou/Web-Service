package com.ahmedbacha_bouherrou.RESTfulService;

import javax.ws.rs.core.Application;
import javax.ws.rs.ApplicationPath;


@ApplicationPath("v1/converterApp")
public class CurrencyConverterApplication extends Application {

}
