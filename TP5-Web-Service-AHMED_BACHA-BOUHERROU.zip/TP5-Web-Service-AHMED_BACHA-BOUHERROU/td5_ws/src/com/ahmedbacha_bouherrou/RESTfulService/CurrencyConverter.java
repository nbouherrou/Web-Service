package com.ahmedbacha_bouherrou.RESTfulService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.ahmedbacha_bouherrou.model.Currency;
import com.ahmedbacha_bouherrou.model.Office;
import com.rest.db.DBClass;
import com.rest.util.ToJSON;

@Path("currencyConverter")
public class CurrencyConverter {

	private String version;

	private static List<Currency> currencyList = new ArrayList<Currency>();

	/*------------------------Code Block Number 1-----------------------*/
	@GET
	@Path("version")
	public String version() {
		return "The current version is " + version;
	}

	@SuppressWarnings("static-access")
	public CurrencyConverter() {
		super();
		if (currencyList.isEmpty()) {
			this.initializeCurrencies();
		}
	}

	private static void initializeCurrencies() {

		currencyList.add(new Currency("USA", "Dollar", 1800, 1));
		currencyList.add(new Currency("EU", "Euro", 2000, 2));
		currencyList.add(new Currency("Japan", "Yen", 1945, 3));
	}

	@GET
	@Path("currency/{identifier:[0-9]*}")
	public Response getCurrencyNameById(@PathParam("identifier") int id) {

		if (id == 1) {

			return Response.status(200).entity("Dollar").build();
		}

		if (id == 2) {

			return Response.status(200).entity("Euro").build();
		}

		if (id == 3) {
			return Response.status(200).entity("Yen").build();
		}

		return Response.status(404).entity("BAD ID !!!!!").build();

	}

	@GET
	@Path("conversion/{source}/{destination}/{amount}")
	public Response convert(@PathParam("source") String source,
			@PathParam("destination") String destination,
			@PathParam("amount") double amount) {

		Double amountConverted = 0d;

		Double device;

		if (source.equals("D") && destination.equals("Y")) {

			device = 118.481;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Yen")
					.build();

		}

		if (source.equals("D") && destination.equals("E")) {

			device = 0.802032;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Euro")
					.build();

		}

		if (source.equals("E") && destination.equals("D")) {

			device = 1.24683;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Dollar")
					.build();

		}

		if (source.equals("E") && destination.equals("Y")) {

			device = 147.726;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Yen")
					.build();

		}

		if (source.equals("Y") && destination.equals("D")) {

			device = 0.00844069;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Dollar")
					.build();

		}

		if (source.equals("Y") && destination.equals("E")) {

			device = 0.00676927;

			amountConverted = amount * device;

			return Response.status(200).entity(amountConverted + " Euro")
					.build();

		}

		return Response.status(404).entity("Error !!!!!").build();

	}

	@GET
	@Path("/currencies")
	@Produces(MediaType.TEXT_XML)
	// URL :
	// http://localhost:8080/td4-ws/v1/converterApp/currencyConverter/currencies?sortedYN=y
	// URL :
	// http://localhost:8080/td4-ws/v1/converterApp/currencyConverter/currencies?sortedYN=n
	public List<Currency> getCurrenciesXML(@QueryParam("sortedYN") String value) {

		if (value.equals("y")) {

			Collections.sort(currencyList, new Comparator<Currency>() {

				public int compare(Currency c1, Currency c2) {

					return c1.getName().compareTo(c2.getName());

				}

			});

		} else {
			Collections.reverse(currencyList);
		}

		return currencyList;

	}

	@GET
	@Path("currencies")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Currency> getCurrenciesJSON(@QueryParam("sortedYN") String value) {

		if (value.equals("y")) {

			Collections.sort(currencyList, new Comparator<Currency>() {

				public int compare(Currency c1, Currency c2) {

					return c1.getName().compareTo(c2.getName());

				}

			});

		} else {
			Collections.reverse(currencyList);
		}

		return currencyList;

	}

	/*
	 * Question 1 Retourne toutes les offices de notre BDD URL :
	 * http://localhost:8080/td4/v1/converterApp/currencyConverter/offices
	 * 
	 * @return String
	 */
	/*
	@GET
	@Path("offices")
	@Produces(MediaType.APPLICATION_JSON)
	public String getOffices() {

		JSONArray array = null;

		ToJSON toJson = new ToJSON();

		Connection conn = DBClass.returnConnection();

		String selectSQL = "SELECT * FROM office";

		PreparedStatement preparedStatement;

		try {

			preparedStatement = conn.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery(selectSQL);

			conn.close();

			array = toJson.toJSONArray(rs);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return array.toString();
	}
	*/

	/*
	 * Question 2 Retourne les offices de la ville correspondante
	 * 
	 * URL :
	 * http://localhost:8080/td4/v1/converterApp/currencyConverter/office?city
	 * =London
	 * 
	 * @param String : city
	 * 
	 * @return String : office(s) de la city
	 * 
	 * @GET
	 * 
	 * @Path("office")
	 * 
	 * @Produces(MediaType.APPLICATION_JSON) public String
	 * getOffice(@QueryParam("city") String city) {
	 * 
	 * JSONArray array = null;
	 * 
	 * ToJSON toJson = new ToJSON();
	 * 
	 * Connection conn = DBClass.returnConnection();
	 * 
	 * PreparedStatement preparedStatement;
	 * 
	 * try {
	 * 
	 * preparedStatement = conn
	 * .prepareStatement("SELECT * FROM office WHERE city = ?");
	 * 
	 * preparedStatement.setString(1, city);
	 * 
	 * ResultSet rs = preparedStatement.executeQuery();
	 * 
	 * conn.close();
	 * 
	 * array = toJson.toJSONArray(rs);
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * return array.toString(); }
	 */

	/*
	 * Question 3
	 * 
	 * URL :
	 * http://localhost:8080/td4/v1/converterApp/currencyConverter/office?city
	 * =London
	 * 
	 * @param String : city
	 * 
	 * @return Response : 200 or 404
	 */
	/*
	 * @GET
	 * 
	 * @Path("office")
	 * 
	 * @Produces(MediaType.APPLICATION_JSON) public Response
	 * getOffice(@QueryParam("city") String city) {
	 * 
	 * JSONArray array = null;
	 * 
	 * ToJSON toJson = new ToJSON();
	 * 
	 * Connection conn = DBClass.returnConnection();
	 * 
	 * PreparedStatement preparedStatement;
	 * 
	 * try {
	 * 
	 * preparedStatement = conn
	 * .prepareStatement("SELECT * FROM office WHERE city = ?");
	 * 
	 * preparedStatement.setString(1, city);
	 * 
	 * ResultSet rs = preparedStatement.executeQuery();
	 * 
	 * conn.close();
	 * 
	 * array = toJson.toJSONArray(rs);
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * try {
	 * 
	 * if (!array.isNull(0)) {
	 * 
	 * return Response.status(200).entity(array.toString()).build(); } else {
	 * 
	 * return Response.status(404).entity("Error !").build(); }
	 * 
	 * } catch (Exception e) {
	 * 
	 * return Response.status(404).entity("Error !").build(); } }
	 */

	/*
	 * Question 4
	 * Insertion en base de donnée d'une office via méthode POST 
	 * Receive Data in form Data
	 * 
	 * URL : http://localhost:8080/td4/v1/converterApp/currencyConverter/offices
	 * 
	 * @param  String   : city, manager, email, year_founded
	 * @return Response : 200 or 404 
	 * 
	 */
	@POST
	@Path("offices")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response addOffice(@FormParam("city") String city,
	@FormParam("manager") String manager,
	@FormParam("email") String email,
	@FormParam("year_founded") String year_founded) {

		if (!city.isEmpty() && !manager.isEmpty() && !email.isEmpty()
				&& !year_founded.isEmpty()) {

			Connection conn = DBClass.returnConnection();

			PreparedStatement preparedStatement;

			try {

				preparedStatement = conn.prepareStatement("INSERT INTO office "
						+ "(city, manager_name, email, year_founded)"
						+ " VALUES (?,?,?,?)");

				preparedStatement.setString(1, city);
				preparedStatement.setString(2, manager);
				preparedStatement.setString(3, email);
				preparedStatement.setString(4, year_founded);

				preparedStatement.executeUpdate();

				conn.close();

				return Response.status(200)
						.entity("Record is inserted into OFFICE table!")
						.build();

			} catch (SQLException e) {

				return Response.status(404).entity("Error !").build();
			}

		} else {

			return Response.status(404).entity("Error !").build();
		}

	}

	/*
	 * Question 5
	 * 
	 * URL : http://localhost:8080/td4/v1/converterApp/currencyConverter/offices_v2
	 * 
	 * Receive Data in form JSON
	 * 
	 * @param   String  : incomingData
	 * @return Response : 200 or 404
	 */
	@POST
	@Path("offices_v2")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addOffice_v2(String incomingData) throws JSONException {
		System.out.println(incomingData);

		JSONObject jsonObject = new JSONObject(incomingData);

		String city = jsonObject.getString("city");
		String manager = jsonObject.getString("manager_name");
		String email = jsonObject.getString("email");
		int year_founded = Integer.parseInt(jsonObject
				.getString("year_founded"));

		Office office = new Office(city, manager, year_founded, email);

		int http_code = InsertOfficeIntoTheDataBase(office);

		if (http_code == 200) {

			return Response.ok().build();
		} else {

			return Response.serverError().build();
		}

	}

	public int InsertOfficeIntoTheDataBase(Office office) {
		Connection connection = DBClass.returnConnection();
		PreparedStatement insert;
		try {
			insert = connection
					.prepareStatement("INSERT INTO office (city, manager_name,email, year_founded)"
							+ "VALUES(?,?,?,?)");
			insert.setString(1, office.getCity());
			insert.setString(2, office.getManager_name());
			insert.setString(3, office.getEmail());
			insert.setInt(4, office.getYear_founded());
			insert.executeUpdate();
			return 200;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 400;
		}
	}

}
